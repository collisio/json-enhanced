
def dummy_json(**kwargs):
    """
    Generate a dummy JSONObject instance
    """
    #TODO
    pass