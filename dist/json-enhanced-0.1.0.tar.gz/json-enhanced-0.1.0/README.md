# json-enhanced
Allow us to query json objects

# testing environment

We have developed a Docker container with all the configuration options, modules and initialized variables so that you can test the operation of the package, just by typing:

```bash build.sh```


