# json-enhanced
Nowadays, communication between API infrastructures commonly uses JSON data. 

This library aims to emulate the behavior of the Django ORM, exporting such functionality to JSON objects.

# Installation

```
pip install json-enhanced
```

# testing environment

We have developed a Docker container with all the configuration options, modules and variables already setted up, so that you can test the behaviour of the package, just by typing:

```bash build.sh```